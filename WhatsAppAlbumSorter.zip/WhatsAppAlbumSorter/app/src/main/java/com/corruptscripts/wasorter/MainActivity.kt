package com.corruptscripts.wasorter

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile

/**
 * Lets the user:
 *  1. Grant "All files access" (required to read WhatsApp's private media folder)
 *  2. Pick a destination album/folder via the system folder picker (SAF)
 *  3. Start the background SortService which does the actual watching/moving
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val PREFS = "wasorter_prefs"
        const val KEY_DEST_URI = "dest_uri"
        const val KEY_WATCHED_CHATS = "watched_chats"
    }

    private lateinit var prefs: SharedPreferences

    private val pickFolderLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
            if (uri != null) {
                // Persist permission across reboots
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                prefs.edit().putString(KEY_DEST_URI, uri.toString()).apply()
                Toast.makeText(this, "Album folder set", Toast.LENGTH_SHORT).show()
                updateUi()
            }
        }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        // Simple programmatic UI so this compiles without needing an XML layout inflate step.
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val statusText = android.widget.TextView(this)
        val grantStorageBtn = android.widget.Button(this).apply {
            text = "1. Grant \"All files access\""
            setOnClickListener { requestManageStorage() }
        }
        val pickFolderBtn = android.widget.Button(this).apply {
            text = "2. Choose destination album"
            setOnClickListener { pickFolderLauncher.launch(null) }
        }
        val grantNotifBtn = android.widget.Button(this).apply {
            text = "3. Grant notification access (optional — for chat/group filtering)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        val watchLabel = android.widget.TextView(this).apply {
            text = "\nWatched chats/groups (leave empty to watch everything).\n" +
                "Type the name EXACTLY as it shows in your notifications:"
        }
        val watchInput = android.widget.EditText(this).apply {
            hint = "e.g. Family Group"
        }
        val watchListView = android.widget.TextView(this)
        val addWatchBtn = android.widget.Button(this).apply {
            text = "Add chat/group"
            setOnClickListener {
                val name = watchInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    val set = prefs.getStringSet(KEY_WATCHED_CHATS, mutableSetOf())!!.toMutableSet()
                    set.add(name)
                    prefs.edit().putStringSet(KEY_WATCHED_CHATS, set).apply()
                    watchInput.text.clear()
                    refreshWatchList(watchListView)
                }
            }
        }
        val clearWatchBtn = android.widget.Button(this).apply {
            text = "Clear watch list (watch everything again)"
            setOnClickListener {
                prefs.edit().putStringSet(KEY_WATCHED_CHATS, mutableSetOf()).apply()
                refreshWatchList(watchListView)
            }
        }

        val startBtn = android.widget.Button(this).apply {
            text = "Start watching WhatsApp photos"
            setOnClickListener { startWatching() }
        }
        val stopBtn = android.widget.Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, SortService::class.java))
                Toast.makeText(this@MainActivity, "Stopped", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(statusText)
        layout.addView(grantStorageBtn)
        layout.addView(pickFolderBtn)
        layout.addView(grantNotifBtn)
        layout.addView(watchLabel)
        layout.addView(watchInput)
        layout.addView(addWatchBtn)
        layout.addView(watchListView)
        layout.addView(clearWatchBtn)
        layout.addView(startBtn)
        layout.addView(stopBtn)
        setContentView(android.widget.ScrollView(this).apply { addView(layout) })

        this.statusView = statusText
        refreshWatchList(watchListView)
        updateUi()
    }

    private var statusView: android.widget.TextView? = null

    private fun updateUi() {
        val hasStorage = hasManageStorage()
        val destUri = prefs.getString(KEY_DEST_URI, null)
        statusView?.text = buildString {
            append("All files access: ${if (hasStorage) "granted" else "NOT granted"}\n")
            append("Destination album: ${if (destUri != null) DocumentFile.fromTreeUri(this@MainActivity, Uri.parse(destUri))?.name else "not set"}\n")
        }
    }

    private fun hasManageStorage(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true
        }
    }

    private fun requestManageStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }

    private fun startWatching() {
        if (!hasManageStorage()) {
            Toast.makeText(this, "Grant \"All files access\" first", Toast.LENGTH_LONG).show()
            return
        }
        if (prefs.getString(KEY_DEST_URI, null) == null) {
            Toast.makeText(this, "Pick a destination album first", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, SortService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Watching started", Toast.LENGTH_SHORT).show()
    }

    private fun refreshWatchList(view: android.widget.TextView) {
        val set = prefs.getStringSet(KEY_WATCHED_CHATS, emptySet()) ?: emptySet()
        view.text = if (set.isEmpty()) {
            "Currently watching: ALL chats/groups"
        } else {
            "Currently watching only:\n" + set.joinToString("\n") { "• $it" }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }
}
