package com.corruptscripts.wasorter

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads WhatsApp notifications (title = contact or group name) so we can tell which
 * chat a newly-arrived photo probably came from. This is the only place that
 * information exists on Android — the media file itself carries no sender/chat data.
 *
 * Matching is done by timing: when a notification from a watched chat/group appears,
 * we record the moment. SortService checks that record before moving a new photo.
 * If no chat/group is in the watch list, everything is left unrestricted (matches all).
 */
class WaNotificationListener : NotificationListenerService() {

    companion object {
        // title (chat/group name) -> last time we saw a notification from it, in millis
        val recentNotifications = java.util.concurrent.ConcurrentHashMap<String, Long>()

        const val WATCHED_PACKAGE_1 = "com.whatsapp"
        const val WATCHED_PACKAGE_2 = "com.whatsapp.w4b"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != WATCHED_PACKAGE_1 && sbn.packageName != WATCHED_PACKAGE_2) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return

        recentNotifications[title] = System.currentTimeMillis()

        // Keep the map small — drop anything older than 60s.
        val cutoff = System.currentTimeMillis() - 60_000
        recentNotifications.entries.removeIf { it.value < cutoff }
    }
}
