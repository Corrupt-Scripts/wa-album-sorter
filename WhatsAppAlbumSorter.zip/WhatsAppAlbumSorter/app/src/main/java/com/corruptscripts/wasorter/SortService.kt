package com.corruptscripts.wasorter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileInputStream

/**
 * Watches WhatsApp's incoming image folders (both the standard "WhatsApp Images" path
 * and the newer per-app scoped-media path used since WhatsApp updated its storage layout)
 * and moves every new photo into the user-chosen album as soon as it lands.
 *
 * Note: WhatsApp does not expose which chat/group a photo came from at the filesystem
 * level, so this moves ALL incoming WhatsApp photos — that's the only thing the OS lets
 * an app distinguish. It still solves the "gallery filling up" problem since none of them
 * touch your normal camera roll / gallery folder anymore.
 */
class SortService : Service() {

    private val observers = mutableListOf<FileObserver>()
    private val recentlySeen = mutableSetOf<String>()

    companion object {
        const val CHANNEL_ID = "wasorter_channel"
        const val NOTIF_ID = 1001

        // Common WhatsApp media paths across versions/variants (WhatsApp + WhatsApp Business).
        val WATCH_PATHS = listOf(
            "WhatsApp/Media/WhatsApp Images",
            "WhatsApp Images",
            "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
            "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Images"
        )
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Watching for new WhatsApp photos…"))
        setupObservers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        observers.forEach { it.stopWatching() }
        observers.clear()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, "WA Album Sorter", NotificationManager.IMPORTANCE_LOW
            )
            mgr.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("WA Album Sorter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setOngoing(true)
            .build()

    private fun setupObservers() {
        val root = Environment.getExternalStorageDirectory()
        for (rel in WATCH_PATHS) {
            val dir = File(root, rel)
            if (!dir.exists() || !dir.isDirectory) continue

            // Watch both the folder itself and its "Private"/"Sent" subfolders if present.
            val targets = mutableListOf(dir)
            listOf("Private", "Sent").forEach { sub ->
                val subDir = File(dir, sub)
                if (subDir.exists()) targets.add(subDir)
            }

            targets.forEach { target ->
                val observer = object : FileObserver(target, CLOSE_WRITE or MOVED_TO) {
                    override fun onEvent(event: Int, path: String?) {
                        if (path == null) return
                        val file = File(target, path)
                        handleNewFile(file)
                    }
                }
                observer.startWatching()
                observers.add(observer)
            }
        }
    }

    private fun handleNewFile(file: File) {
        if (!file.exists()) return
        if (!file.name.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") }) return

        val key = file.absolutePath
        synchronized(recentlySeen) {
            if (recentlySeen.contains(key)) return
            recentlySeen.add(key)
        }

        // Give WhatsApp a moment to finish writing/thumbnailing before we move it.
        Thread {
            try {
                waitUntilStable(file)
                moveToDestination(file)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                synchronized(recentlySeen) { recentlySeen.remove(key) }
            }
        }.start()
    }

    private fun waitUntilStable(file: File, checks: Int = 3, intervalMs: Long = 400) {
        var lastSize = -1L
        var stableCount = 0
        while (stableCount < checks) {
            if (!file.exists()) return
            val size = file.length()
            if (size == lastSize) {
                stableCount++
            } else {
                stableCount = 0
                lastSize = size
            }
            Thread.sleep(intervalMs)
        }
    }

    /**
     * If the user hasn't picked any chats/groups to watch, everything matches (old
     * behaviour — move all incoming WhatsApp photos). If they have, only proceed
     * when a notification from one of those exact names arrived in the last few
     * seconds, which is our best available signal for "this photo came from that chat."
     */
    private fun isFromWatchedChat(prefs: android.content.SharedPreferences): Boolean {
        val watchList = prefs.getStringSet(MainActivity.KEY_WATCHED_CHATS, emptySet()) ?: emptySet()
        if (watchList.isEmpty()) return true

        val now = System.currentTimeMillis()
        val windowMs = 8000L // how close in time a matching notification must be
        return watchList.any { name ->
            val seenAt = WaNotificationListener.recentNotifications[name]
            seenAt != null && (now - seenAt) <= windowMs
        }
    }

    private fun moveToDestination(file: File) {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)

        if (!isFromWatchedChat(prefs)) {
            // Not from a chat/group we care about (and a watch list is actually set) —
            // leave the file where WhatsApp put it.
            return
        }

        val destUriStr = prefs.getString(MainActivity.KEY_DEST_URI, null) ?: return
        val destTree = DocumentFile.fromTreeUri(this, Uri.parse(destUriStr)) ?: return

        // Avoid duplicate copies if this file was already moved.
        if (destTree.findFile(file.name) != null) {
            file.delete()
            return
        }

        val mime = when {
            file.name.lowercase().endsWith(".png") -> "image/png"
            file.name.lowercase().endsWith(".webp") -> "image/webp"
            else -> "image/jpeg"
        }

        val newDoc = destTree.createFile(mime, file.name) ?: return
        contentResolver.openOutputStream(newDoc.uri)?.use { out ->
            FileInputStream(file).use { input ->
                input.copyTo(out)
            }
        }

        // Remove the original so it disappears from the normal gallery/WhatsApp Images folder.
        val deleted = file.delete()

        // Refresh the media store so the old entry vanishes and the app's own gallery
        // apps notice both the deletion and, if the destination is on shared storage,
        // the new file.
        if (deleted) {
            MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), null, null)
        }
    }
}
