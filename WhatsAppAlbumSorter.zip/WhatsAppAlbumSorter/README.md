# WA Album Sorter

Watches WhatsApp's incoming photo folder(s) and automatically moves every new photo
into an album/folder you choose, so they stop cluttering your main gallery.

## Important limitation (please read)

Android and WhatsApp don't expose *which chat or group* a photo came from at the
filesystem level — WhatsApp just drops every incoming image into the same
"WhatsApp Images" folder regardless of sender. To let you pick specific chats/groups,
this app instead reads WhatsApp's **notifications** (which do show the sender/group
name) and matches a newly-arrived photo to whichever watched chat had a notification
in roughly the last 8 seconds. It's a timing-based match, not a guaranteed one — if
two photos land from different chats within a second or two of each other, one could
get misattributed. Leave the watch list empty and it falls back to moving everything,
which is fully reliable.

## First-run setup on your phone

1. Open the app.
2. Tap **"1. Grant All files access"** — WhatsApp's media folder is otherwise
   off-limits to apps (a normal Android 11+ restriction).
3. Tap **"2. Choose destination album"** — pick or create the folder you want
   photos to land in.
4. (Optional, only needed if you want specific chats/groups) Tap
   **"3. Grant notification access"**, find "WA Album Sorter" in the list that
   opens, and enable it.
5. (Optional) Under "Watched chats/groups," type each chat or group name **exactly**
   as it appears in your WhatsApp notifications, tapping "Add chat/group" for each
   one. Leave this empty to keep moving every incoming photo.
6. Tap **"Start watching WhatsApp photos"**.

A persistent low-priority notification will show while it's running (required by
Android for any app doing background file watching). It also restarts itself after
a reboot as long as you've completed setup once.

## Notes / things you may want to tune

- `SortService.WATCH_PATHS` lists the folder paths it watches — covers both the
  older "WhatsApp Images" location and the newer Android/media/com.whatsapp path,
  plus WhatsApp Business. If a future WhatsApp update changes the path again,
  add it there.
- It waits for a file's size to stop changing for ~1.2s before moving it, so it
  doesn't grab a half-written file mid-download.
- Duplicate filenames in the destination are skipped (original just gets deleted)
  rather than overwritten.
