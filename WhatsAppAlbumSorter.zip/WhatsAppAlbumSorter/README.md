# WA Album Sorter

Watches WhatsApp's incoming photo folder(s) and automatically moves every new photo
into an album/folder you choose, so they stop cluttering your main gallery.

## Important limitation (please read)

Android and WhatsApp don't expose *which chat or group* a photo came from at the
filesystem level — WhatsApp just drops every incoming image into the same
"WhatsApp Images" folder regardless of sender. So this app can't selectively grab
"only group photos." It moves **every** photo WhatsApp receives into your chosen
album. That still fixes the original problem (your normal gallery no longer fills
up), it just isn't group-specific.

(The only way to get group-specific behaviour would be a NotificationListenerService
that parses notification text to guess the sender/group name — that's fragile,
breaks with WhatsApp updates, and easily misses photos if you have notifications
grouped/muted, so it's not included here.)

## How to build

1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync — it will pull the AndroidX/Material dependencies automatically.
3. Build > Build Bundle(s)/APK(s) > Build APK(s), or just hit Run with your phone
   connected (enable USB debugging).

## First-run setup on your phone

1. Open the app.
2. Tap **"Grant All files access"** — this opens Android's special-permissions
   screen. WhatsApp's media folder is off-limits to apps otherwise (this is a
   normal Android 11+ restriction, not specific to this app).
3. Tap **"Choose destination album"** — pick or create the folder you want photos
   to land in (e.g. a folder under Pictures called "WhatsApp Sorted").
4. Tap **"Start watching WhatsApp photos"**.

A persistent low-priority notification will show while it's running (required by
Android for any app doing background file watching). It also restarts itself after
a reboot as long as you've completed setup once.

## Notes / things you may want to tune

- `SortService.WATCH_PATHS` lists the folder paths it watches — covers both the
  older "WhatsApp Images" location and the newer Android/media/com.whatsapp path,
  plus WhatsApp Business. If a future WhatsApp update changes the path again,
  add it there.
- It waits for a file's size to stop changing for ~1.2s before moving it, so it
  doesn't grab a half-written file mid-download.
- Duplicate filenames in the destination are skipped (original just gets deleted)
  rather than overwritten.
